import pytest
import Utilities
from Config.config import TestData
from Pages.LoginPage import LoginPage
from Tests.test_base import BaseTest


class Test_Login(BaseTest):

    def test_loginWithEmail_button_visible(self):
        self.loginPage = LoginPage(self.driver)
        flag=self.loginPage.is_loginWithEmail_link_exist()
        assert flag

    def test_loginPage_title(self):
        self.loginPage=LoginPage(self.driver)
        title = self.loginPage.get_title(TestData.Login_Page_Title)
        assert title == TestData.Login_Page_Title

    def test_login(self):
        self.loginPage=LoginPage(self.driver)
        self.loginPage.do_login(TestData.email,TestData.password)

    def test_blank_email_login(self):
        self.loginPage=LoginPage(self.driver)
        self.loginPage.blank_email_login(TestData.password)

    def test_blank_password_login(self):
        self.loginPage=LoginPage(self.driver)
        self.loginPage.blank_password_login(TestData.email)

    def test_blank_email_password_login(self):
        self.loginPage=LoginPage(self.driver)
        self.loginPage.blank_email_password_login()

    def test_forgot_password(self):
        self.loginPage=LoginPage(self.driver)
        self.loginPage.forgot_password(TestData.email)

