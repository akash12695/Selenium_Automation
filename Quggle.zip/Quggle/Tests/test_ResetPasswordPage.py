import pytest
import Utilities
from Config.config import TestData
from Pages.HomePage import HomePage
from Pages.LoginPage import LoginPage
from Pages.ResetPasswordPage import ResetPasswordPage
from Tests.test_base import BaseTest


class Test_ResetPassword(BaseTest):
    def test_retestPassword(self):
        self.loginPage = LoginPage(self.driver)
        self.homepage= HomePage(self.driver)
        homePage= self.loginPage.do_login(TestData.email, TestData.password)
        resetpassword = self.homepage.is_account_icon_exist()
        resetpassword.reset_password()
