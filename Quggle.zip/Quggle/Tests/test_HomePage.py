from Config.config import TestData
from Pages.LoginPage import LoginPage
from Tests.test_base import BaseTest


class Test_DRIQuerying(BaseTest):
    def test_driQueryingPage_title(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email, TestData.password)
        homePage_title = homePage.get_homePage_title(TestData.HOME_PAGE_TITLE)
        assert homePage_title == TestData.HOME_PAGE_TITLE

    # def test_driQueryingPage_text(self):
    #     self.loginPage = LoginPage(self.driver)
    #     homePage = self.loginPage.do_login(TestData.email,TestData.password)
    #     driQueryingPage_text = driQueryingPage.get_driQueryingPage_text()
    #     assert driQueryingPage_text ==TestData.DRI_QUERYING_Text

    def test_accountName_text(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email,TestData.password)
        accountName=homePage.get_accountName_value()
        assert accountName == TestData.ACCOUNT_NAME

    def test_questionMark_icon(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email,TestData.password)
        assert homePage.is_questionMark_icon_exist()

    def test_projectDri_icon(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email,TestData.password)
        assert homePage.is_project_icon_exist()

    def test_account_icon(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email,TestData.password)
        assert homePage.is_account_icon_exist()

    def test_driQuerying_button(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email,TestData.password)
        assert homePage.is_driQuerying_button_exist()

    def test_driSubmission_button(self):
        self.loginPage = LoginPage(self.driver)
        homePage = self.loginPage.do_login(TestData.email,TestData.password)
        assert homePage.is_driSubmission_button_exist()
