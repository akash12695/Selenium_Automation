import pytest
import Utilities
from Config.config import TestData
from Pages.HomePage import HomePage
from Pages.LoginPage import LoginPage
from Pages.ResetPasswordPage import ResetPasswordPage
from Tests.test_base import BaseTest

class Test_ViewUploadedProfile(BaseTest):
    def test_viewUploadedProfile(self):
        self.loginPage = LoginPage(self.driver)
        self.homepage= HomePage(self.driver)
        homePage= self.loginPage.do_login(TestData.email, TestData.password)
        viewUploadedProfile= self.homepage.is_viewUploadedProfile_exist()
        viewUploadedProfile.search_user(TestData.NAME)

    def test_top_checkBox_clickable(self):
        self.loginPage = LoginPage(self.driver)
        self.homepage= HomePage(self.driver)
        homePage= self.loginPage.do_login(TestData.email, TestData.password)
        viewUploadedProfile= self.homepage.is_viewUploadedProfile_exist()
        viewUploadedProfile.is_top_checkBox_clickable(TestData.NAME)

    def test_clearSelectionLink_clickable(self):
        self.loginPage = LoginPage(self.driver)
        self.homepage= HomePage(self.driver)
        homePage= self.loginPage.do_login(TestData.email, TestData.password)
        viewUploadedProfile= self.homepage.is_viewUploadedProfile_exist()
        viewUploadedProfile.is_clear_selection(TestData.NAME)

    def test_deleteSelectedProfiles(self):
        self.loginPage = LoginPage(self.driver)
        self.homepage= HomePage(self.driver)
        homePage= self.loginPage.do_login(TestData.email, TestData.password)
        viewUploadedProfile= self.homepage.is_viewUploadedProfile_exist()
        viewUploadedProfile.delete_selected_profiles(TestData.NAME)
