import time

def screenShot_LoginPage(driver,ss_name):
    folder="C:\\Users\\Akash Mishra\\PycharmProjects\\Quggle\\Screenshots\\LoginPage\\"
    file_name= folder + ss_name + " " + ".png"
    driver.save_screenshot(file_name)
    # driver.get_screenshot_as_file(file_name)   another way to take screenshot.

def screenShot_HomePage(driver,ss_name):
    folder="C:\\Users\\Akash Mishra\\PycharmProjects\\Quggle\\Screenshots\\HomePage\\"
    # time_string=time.asctime().replace(":"," ")
    file_name = folder + ss_name + " " + ".png"
    driver.save_screenshot(file_name)

def screenShot_ResetPassword(driver,ss_name):
    folder="C:\\Users\\Akash Mishra\\PycharmProjects\\Quggle\\Screenshots\\ResetPassword\\"
    file_name= folder + ss_name + " " + ".png"
    driver.save_screenshot(file_name)

def screenShot_ViewUploadedProfile(driver,ss_name):
    folder="C:\\Users\\Akash Mishra\\PycharmProjects\\Quggle\\Screenshots\\ViewUploadedProfile\\"
    file_name= folder + ss_name + " " + ".png"
    driver.save_screenshot(file_name)
