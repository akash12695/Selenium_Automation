class TestData:
    base_url ="https://dri-demo.qcaps-quggle.com/frontend/"
    email ="testing.akash@outlook.com"
    password = "Akash@123"
    Login_Page_Title = "Partner DRI"

    ACCOUNT_NAME = "Akash"
    HOME_PAGE_TITLE = "Partner DRI"

    NAME="First Last17"
