import time

from selenium.webdriver.common.by import By

from Pages.BasePage import BasePage
from Utilities import Screenshots


class ResetPasswordPage(BasePage):
    ACCOUNT_ICON= (By.XPATH,"//mat-icon[@class='mat-icon notranslate vector material-icons mat-icon-no-color']")
    RESET_PASSWORD = (By.XPATH,"//button[text()='Reset Password']")

    def __init__(self, driver):
        super().__init__(driver)

    def reset_password(self):
        self.do_click(self.ACCOUNT_ICON)
        self.do_click(self.RESET_PASSWORD)
        time.sleep(2)
        Screenshots.screenShot_ResetPassword(self.driver, "On Clicking Reset Password button")

