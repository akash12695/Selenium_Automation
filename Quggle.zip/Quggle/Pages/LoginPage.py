import time

from selenium.webdriver.common.by import By
from Utilities import Screenshots
from Config.config import TestData
from Pages.BasePage import BasePage
from Pages.HomePage import HomePage


class LoginPage(BasePage):

    """By Locator or Object Repository"""

    LoginWithEmail = (By.XPATH, "//button[@class='mat-focus-indicator email-login-button no-box-shadow "
                                "mat-raised-button mat-button-base']")
    EMAIL = (By.XPATH, "//input[@id='email']")
    PASSWORD = (By.XPATH,"//input[@id='password']")
    LOGIN_BUTTON = (By.XPATH,"//button[@class='mat-focus-indicator login-now-button no-box-shadow mat-raised-button "
                             "mat-button-base']")
    FORGOT_PASSWORD = (By.XPATH,"//span[text()='Forgot Password']")
    FORGOT_PASSWORD_EMAIL = (By.XPATH,"//input[@id='user-email']")
    SUBMIT_BUTTON = (By.XPATH,"//button[@id='btn-left']")
    CANCEL_BUTTON = (By.XPATH,"//button[@id='btn-right']")
    OK_BUTTON = (By.XPATH,"//button[@class='mat-focus-indicator button-style mat-raised-button mat-button-base']")

    """Constructor of the LoginPage class"""
    def __init__(self,driver):
        super().__init__(driver)
        self.driver.get(TestData.base_url)

    """LoginPage Actions"""

    """This is use to get the LoginPage Title"""
    def get_login_page_title(self,title):
        return self.get_title(title)

    """This is use to check is login With Email button exist"""
    def is_loginWithEmail_link_exist(self):
        return self.is_visible(self.LoginWithEmail)

    """This is use to login into the Application"""
    def do_login(self,email,password):
        self.do_click(self.LoginWithEmail)
        self.do_send_keys(self.EMAIL,email)
        self.do_send_keys(self.PASSWORD,password)
        Screenshots.screenShot_LoginPage(self.driver,"LoginPage")
        self.do_click(self.LOGIN_BUTTON)
        return HomePage(self.driver)

    def blank_email_login(self,password):
        self.do_click(self.LoginWithEmail)
        self.do_send_keys(self.PASSWORD, password)
        self.do_click(self.LOGIN_BUTTON)
        Screenshots.screenShot_LoginPage(self.driver, "Blank Email Login")

    def blank_password_login(self,email):
        self.do_click(self.LoginWithEmail)
        self.do_send_keys(self.EMAIL, email)
        self.do_click(self.LOGIN_BUTTON)
        Screenshots.screenShot_LoginPage(self.driver, "Blank Password Login")


    def blank_email_password_login(self):
        self.do_click(self.LoginWithEmail)
        self.do_click(self.LOGIN_BUTTON)
        Screenshots.screenShot_LoginPage(self.driver, "Blank Email and Password Login")

    def forgot_password(self,email):
        self.do_click(self.LoginWithEmail)
        self.do_click(self.FORGOT_PASSWORD)
        Screenshots.screenShot_LoginPage(self.driver, "Reset password Pop Up")
        time.sleep(1)
        self.do_send_keys(self.FORGOT_PASSWORD_EMAIL,email)
        self.do_click(self.SUBMIT_BUTTON)
        Screenshots.screenShot_LoginPage(self.driver, "Mail sent successfully to provided email id")
        self.do_click(self.OK_BUTTON)
