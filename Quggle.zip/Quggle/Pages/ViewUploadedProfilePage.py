import time

from selenium.webdriver.common.by import By

from Pages.BasePage import BasePage
from Pages.ResetPasswordPage import ResetPasswordPage
from Utilities import Screenshots


class ViewUploadedProfilePage(BasePage):
    ACCOUNT_ICON = (By.XPATH, "//mat-icon[@class='mat-icon notranslate vector material-icons mat-icon-no-color']")
    VIEW_UPLOADED_PROFILE_BUTTON = (By.XPATH, "//button[text()='View uploaded profiles']")
    SEARCH_BAR = (By.XPATH, "//input[@class='searchbar']")
    SEARCH_ICON = (By.XPATH, "//span[@class='search-icon']")
    TOP_CHECKBOX = (By.XPATH, "//input[@id='mat-checkbox-1-input']//parent::span")
    CLEAR_SELECTION = (By.XPATH, "//span[text()=' Clear selection ']")
    FIRST_ROW_CHECKBOX = (By.XPATH, "//tr[@class='mat-row cdk-row ng-star-inserted'][1]//td[1]//span["
                                    "@class='mat-checkbox-inner-container "
                                    "mat-checkbox-inner-container-no-side-margin']")
    DELETE_SELECTED_PROFILES = (By.XPATH,"//span[text()='Delete selected profiles']")
    DELETE_BUTTON = (By.XPATH,"//button[text()='Delete']")
    def __init__(self, driver):
        super().__init__(driver)

    def search_user(self, name):
        self.do_click(self.ACCOUNT_ICON)
        self.do_click(self.VIEW_UPLOADED_PROFILE_BUTTON)
        self.do_send_keys(self.SEARCH_BAR, name)
        time.sleep(1)
        self.do_click(self.SEARCH_ICON)
        time.sleep(2)
        Screenshots.screenShot_ViewUploadedProfile(self.driver, "Search Bar working as expected")

    def is_top_checkBox_clickable(self, name):
        self.search_user(name)
        self.do_click(self.TOP_CHECKBOX)
        time.sleep(1)
        Screenshots.screenShot_ViewUploadedProfile(self.driver, "CheckBox functionality is working as expected")

    def is_clear_selection(self, name):
        self.is_top_checkBox_clickable(name)
        self.do_click(self.CLEAR_SELECTION)
        time.sleep(1)
        Screenshots.screenShot_ViewUploadedProfile(self.driver, "Clear Selection link is working as expected")

    def delete_selected_profiles(self,name):
        self.search_user(name)
        self.do_click(self.FIRST_ROW_CHECKBOX)
        time.sleep(1)
        self.do_click(self.DELETE_SELECTED_PROFILES)
        self.do_click(self.DELETE_BUTTON)
        time.sleep(2)
        Screenshots.screenShot_ViewUploadedProfile(self.driver, "Delete Selected Profile is working as expected")
