import time

from selenium.webdriver.common.by import By

from Pages.BasePage import BasePage
from Pages.ResetPasswordPage import ResetPasswordPage
from Pages.ViewUploadedProfilePage import ViewUploadedProfilePage
from Utilities import Screenshots


class HomePage(BasePage):

    ACCOUNT_NAME = (By.XPATH,"//span[@class='username']")
    ACCOUNT_ICON = (By.XPATH," //mat-icon[@class='mat-icon notranslate vector material-icons mat-icon-no-color']")
    QUESTION_MARK_ICON = (By.XPATH," //img[@class='mat-menu-trigger help-logo']")
    PROJECT_ICON = (By.XPATH," //img[@class='ng-star-inserted']")
    DRI_QUERYING_BUTTON = (By.XPATH," //span[text()='DRI Querying']")
    DRI_SUBMISSION_BUTTON = (By.XPATH," //span[text()='DRI Submission']")
    TEXT = (By.XPATH," //p[@class='content']")

    def __init__(self,driver):
        super().__init__(driver)

    """This is use to get the DRI Querying Page Title"""

    def get_homePage_title(self,title):
        return self.get_title(title)
        # Screenshots.screenShot_HomePage(self.driver)

    """This is use to check is Question Mark icon exist"""
    def is_questionMark_icon_exist(self):
        return self.is_visible(self.QUESTION_MARK_ICON)

    """This is use to check is Project DRI icon exist"""
    def is_project_icon_exist(self):
        return self.is_visible(self.PROJECT_ICON)

    """This is use to check is Account circle icon exist"""
    def is_account_icon_exist(self):
        return ResetPasswordPage(self.driver)

    """This is use to check is DRI Querying button exist"""
    def is_driQuerying_button_exist(self):
        # Screenshots.screenShot_HomePage(self.driver)
        return self.is_visible(self.DRI_QUERYING_BUTTON)


    """This is use to check is DRI Submission button exist"""
    def is_driSubmission_button_exist(self):
        if self.is_visible(self.DRI_SUBMISSION_BUTTON):
            time.sleep(1)
            Screenshots.screenShot_HomePage(self.driver,"DRI_Submission_button")
        return self.is_visible(self.DRI_SUBMISSION_BUTTON)


    """This is use to get the Account name displayed on top right corner of DRI Querying Page"""
    def get_accountName_value(self):
        if self.is_visible(self.ACCOUNT_NAME):
            time.sleep(1)
            Screenshots.screenShot_HomePage(self.driver,"Account_Name")
            return self.get_element_text(self.ACCOUNT_NAME)

    """This is use to check inside Account circle icon View Uploaded Profile exist"""
    def is_viewUploadedProfile_exist(self):
        return ViewUploadedProfilePage(self.driver)
