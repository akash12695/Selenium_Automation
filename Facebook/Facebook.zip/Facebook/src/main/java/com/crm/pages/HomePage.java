package com.crm.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;

public class HomePage extends TestBase {

//	@FindBy(xpath = "//span[contains(text(),\"Akash Mishra\")]")
//	WebElement userNameLabel;

	@FindBy(xpath = "//a[contains(@aria-label,\"Groups\")]")
	WebElement groupIcon;
	
	@FindBy(xpath="//span[text()=\"UpComing South Indian Hindi Dubbed Movies Updates :-\"]")
	WebElement upComingSouthIndianHindiUpdates;
	
	@FindBy(xpath="//span[text()=\'Create a public post�\']")
	WebElement createPublicPostClick;
	
	@FindBy(xpath="//div[@class='bi6gxh9e']/div")
	WebElement createPublicPostType;


	public HomePage() throws IOException {
		PageFactory.initElements(driver, this); // Driver is coming from base class and "this" means its pointing to
												// current class objects
	}

	public ContactsPage clickOnGroupIcon(String link1) throws IOException, InterruptedException {
		groupIcon.click();
		upComingSouthIndianHindiUpdates.click();		
		createPublicPostClick.click();
		Thread.sleep(1000);
		createPublicPostType.click();
		//Thread.sleep(2000);
		createPublicPostType.sendKeys(link1);
		
 
		
		
		
		return new ContactsPage();   //Whenever we are clicking on Any link then it should return the next page

	}

}
