package com.crm.pages;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;
import com.crm.utils.TestUtil;

public class LoginPage extends TestBase {

	// PageFactory or Object Repository

	@FindBy(xpath = "//input[contains(@id,'email')]")
	WebElement email;

	@FindBy(xpath = "//input[contains(@id,'pass')]")
	WebElement password;

	@FindBy(xpath = "//button[contains(@name,'login')]")
	WebElement loginBtn;

	// Initializing the Objects
	public LoginPage() throws IOException {
		PageFactory.initElements(driver, this); // Driver is coming from base class and "this" means its pointing to
												// current class objects

	}

	public HomePage login(String mail, String pwd) throws IOException {
//		login.click();
		email.sendKeys(mail);
		password.sendKeys(pwd);
		loginBtn.click();
	
		return new HomePage();
	}

}
