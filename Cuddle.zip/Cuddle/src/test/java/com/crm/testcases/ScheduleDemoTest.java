package com.crm.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.base.TestBase;
import com.crm.pages.ScheduleDemo;
import com.crm.pages.CuddleHomePage;

public class ScheduleDemoTest extends TestBase {

	CuddleHomePage cuddleHomePage;
	ScheduleDemo scheduleDemo;

	public ScheduleDemoTest() throws IOException {
		super();

	}

	// @Before each testcase --- Launch the browser and Login
	// @test-- execute the testcases
	// @After each testcase --- close the browser

	@BeforeMethod
	public void setUp() throws IOException, InterruptedException {
		initialization(); // initialization is called from the TestBase parent class to initialize the
							// browser
		cuddleHomePage = new CuddleHomePage();
		scheduleDemo = cuddleHomePage.cuddleHomePage();

	}

	@Test
	public void scheduleDemoTest() throws IOException, InterruptedException {
		scheduleDemo.scheduleEvent(prop.getProperty("name"), prop.getProperty("mail"), prop.getProperty("number"),
				prop.getProperty("note"));

	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
