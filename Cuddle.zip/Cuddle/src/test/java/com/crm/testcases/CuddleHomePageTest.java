package com.crm.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.base.TestBase;
import com.crm.pages.ScheduleDemo;
import com.crm.pages.CuddleHomePage;

public class CuddleHomePageTest extends TestBase {

	CuddleHomePage cuddleHomePage;
	ScheduleDemo scheduleDemo;

	public CuddleHomePageTest() { // Constructor for LoginPageTest() class
		super(); // It will go the the Parent class(TestBase)

	}

	@BeforeMethod
	public void setUp() throws IOException {
		initialization(); // initialization is called from the TestBase parent class to initialize the
							// browser
		cuddleHomePage = new CuddleHomePage(); // created an object of cuddleHomePage class so that we can call the
												// methods from CuddleHomePage class to cuddleHomePageTest Class
		
	}

	@Test(priority = 1)
	public void loginTest() throws IOException, InterruptedException {
		scheduleDemo = cuddleHomePage.cuddleHomePage();
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
