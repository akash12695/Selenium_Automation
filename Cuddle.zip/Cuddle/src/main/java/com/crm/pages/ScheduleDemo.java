package com.crm.pages;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;

public class ScheduleDemo extends TestBase {

	@FindBy(xpath = "//button[@aria-label='Thursday, April 29']//child::span")
	WebElement dateButton;

	@FindBy(xpath = "//button[contains(@data-start-time,'7:30pm')]")
	WebElement timeButton;

	@FindBy(xpath = "//button[@class='_2OQqVeh6S4 _1Es3W-g9AL _4rcXoQPLhG _3jdvikh0KV _1NKUM54h_1 confirm-button-enter-done']")
	WebElement confirmButton;

	@FindBy(xpath = "//input[contains(@name,'full_name')]")
	WebElement fullName;

	@FindBy(xpath = "//input[contains(@name,'email')]")
	WebElement email;

	@FindBy(xpath = "//input[contains(@name,'question_0')]")
	WebElement phoneNumber;

	@FindBy(xpath = "//input[contains(@name,'question_1')]")
	WebElement notes;

	public ScheduleDemo() throws IOException {
		PageFactory.initElements(driver, this); // Driver is coming from base class and "this" means its pointing to
												// current class objects
	}

	public void scheduleEvent(String name, String mail, String number, String note)
			throws IOException, InterruptedException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,250)");

		driver.switchTo().frame(0);

		dateButton.click();
		timeButton.click();
		confirmButton.click();
		Thread.sleep(2000);
		fullName.sendKeys(name);
		Thread.sleep(2000);
		email.sendKeys(mail);
		phoneNumber.sendKeys(number);
		notes.sendKeys(note);
		Thread.sleep(2000);

///////////******** Thread.sleep(2000) is only used just that the activities whichever i am performing should be visible in the recorded video which i am sending to the Cuddle Team *************/////////////////

	}

}
