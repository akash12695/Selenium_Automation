package com.crm.pages;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;
import com.crm.utils.TestUtil;

public class CuddleHomePage extends TestBase {

	// PageFactory or Object Repository

	@FindBy(xpath = "//a[contains(@title,'Capabilities')]")
	WebElement capabilities;

	@FindBy(xpath = "//a[contains(@title,'Solutions')]")
	WebElement solutions;

	@FindBy(xpath = "//a[contains(@title,'Resources')]")
	WebElement resources;

	@FindBy(xpath = "//a[text()='Schedule a Demo' and @class='d-header-appointment']")
	WebElement scheduleADemo;

	// Initializing the Objects
	public CuddleHomePage() throws IOException {
		PageFactory.initElements(driver, this); // Driver is coming from base class and "this" means its pointing to
												// current class objects

	}

	public ScheduleDemo cuddleHomePage() throws IOException, InterruptedException {
//		login.click();
		capabilities.click();
		Thread.sleep(1000);
		solutions.click();
		Thread.sleep(1000);
		resources.click();
		Thread.sleep(1000);
		scheduleADemo.click();

///////////******** Thread.sleep(1000) is only used just that the activities whichever i am performing should be visible in the recorded video which i am sending to the Cuddle Team *************/////////////////

		return new ScheduleDemo();
	}

}
