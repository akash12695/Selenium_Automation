package com.crm.testcases;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.crm.base.TestBase;
import com.crm.pages.ContactsPage;
import com.crm.pages.HomePage;
import com.crm.pages.LoginPage;
import com.crm.utils.TestUtil;

public class ContactsPageTest extends TestBase {

	LoginPage loginPage;
	HomePage homePage;
	ContactsPage contactsPage;
	String sheetName = "contacts";

	public ContactsPageTest() throws IOException {
		super();
	}

	@BeforeMethod
	public void setUp() throws IOException {
		initialization();
		contactsPage = new ContactsPage();
		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
		contactsPage = homePage.clickOnContactLink();

	}

	@Test(priority = 1)
	public void verifyContactsPageLabel() {
		Assert.assertTrue(contactsPage.verifyContactsLabel(), "Contact label is missing on the page");
		;
	}

	// For the below testcase I am using Page Object Model With Data Driven Approch

	@DataProvider // @dataprovider is fetching the data from getTestData() method and returning
					// the 2D array
	public Object[][] getCRMTestData() throws InvalidFormatException {
		Object data[][] = TestUtil.getTestData(sheetName); // Stored the data in 2D array since in TestUtil Class we
															// have also saved the data in 2D array
															// all the testcase are now avail in the data[][]
		return data;
	}

	@Test(priority = 2, dataProvider = "getCRMTestData")
	public void validateCreateNewContact(String firstName, String lastName, String address)
			throws InterruptedException {
		Thread.sleep(2000);
		contactsPage.clickOnNewButton(firstName, lastName, address);
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
