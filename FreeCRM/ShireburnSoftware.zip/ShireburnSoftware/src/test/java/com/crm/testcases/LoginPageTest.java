package com.crm.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.base.TestBase;
import com.crm.pages.HomePage;
import com.crm.pages.LoginPage;


public class LoginPageTest extends TestBase {

	LoginPage loginPage;
	HomePage homePage;

	public LoginPageTest()  { // Constructor for LoginPageTest() class
		super(); // It will go the the Parent class(TestBase)

	}

	@BeforeMethod
	public void setUp() throws IOException {
		initialization(); // initialization is called from the TestBase parent class to initialize the
							// browser
		loginPage = new LoginPage(); // created an object of loginPage class so that we can call the methods from
										// LoginPage class to LoginPageTest Class
	}

	@Test(priority = 1)
	public void loginPageTitleTest() {
		String title = loginPage.validateLoginPageTitle();
		Assert.assertEquals(title, "Free CRM #1 cloud software for any business large or small");
	}

	@Test(priority = 2)
	public void androidLogoImageTest() {
		boolean flag = loginPage.validateAndroidImage();
		Assert.assertTrue(flag);
	}

	@Test(priority = 3)
	public void loginTest() throws IOException{
		homePage = loginPage.login(prop.getProperty("email"), prop.getProperty("password"));
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
