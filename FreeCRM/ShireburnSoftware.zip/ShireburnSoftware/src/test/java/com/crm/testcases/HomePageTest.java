package com.crm.testcases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.crm.base.TestBase;
import com.crm.pages.ContactsPage;
import com.crm.pages.HomePage;
import com.crm.pages.LoginPage;

public class HomePageTest extends TestBase {

	LoginPage loginPage;
	HomePage homePage;
	ContactsPage contactsPage;

	public HomePageTest() throws IOException {
		super();

	}

	// Testcases should always be separated or independent of each other
	// Before each testcase --- Launch the browser and Login
	// @test-- execute the testcases
	// After each testcase --- close the browser

	@BeforeMethod
	public void setUp() throws IOException {
		initialization();
		loginPage = new LoginPage();
		contactsPage = new ContactsPage();
		homePage = loginPage.login(prop.getProperty("email"), prop.getProperty("password")); // loginPage is return next
																								// landing page object
																								// i.e. homePage
	}

	@Test(priority = 1)
	public void verifyHomePageTitleTest() {
		String homePageTitle = homePage.verifyHomePageTitle();
		Assert.assertEquals(homePageTitle, "Cogmento CRM", "Home Page Title not matched"); // "Home Page Title not
																							// matched" will only get
																							// printed if the testcase
																							// is failed
	}

	@Test(priority = 2)
	public void verifyUserNameTest() {
		Assert.assertTrue(homePage.verifyCorrectUserName());

	}

	@Test(priority = 3)
	public void verifyContactLinkTest() throws IOException {
		contactsPage = homePage.clickOnContactLink();

	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

}
