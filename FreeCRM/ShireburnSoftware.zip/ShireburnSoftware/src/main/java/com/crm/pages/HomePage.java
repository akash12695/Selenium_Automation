package com.crm.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;

public class HomePage extends TestBase {

	@FindBy(xpath = "//span[contains(text(),\"Akash Mishra\")]")
	WebElement userNameLabel;

	@FindBy(xpath = "//span[contains(text(),'Contacts')]")
	WebElement contactsLink;

	@FindBy(xpath = "//span[contains(text(),'Deals')]")
	WebElement dealsLink;

	public HomePage() throws IOException {
		PageFactory.initElements(driver, this); // Driver is coming from base class and "this" means its pointing to
												// current class objects
	}

	public String verifyHomePageTitle() {
		return driver.getTitle();

	}
	
	public boolean verifyCorrectUserName() {
		return userNameLabel.isDisplayed();
	}

	public ContactsPage clickOnContactLink() throws IOException {
		contactsLink.click();
		return new ContactsPage();   //Whenever we are clicking on Any link then it should return the next page

	}

}
