package com.crm.pages;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;
import com.crm.utils.TestUtil;

public class LoginPage extends TestBase {

	// PageFactory or Object Repository

	@FindBy(xpath = "//span[contains(text(),\"Log In\")]")
	WebElement login;

	@FindBy(xpath = "//img[contains(@title,\"app for freecrm android\")]")
	WebElement androidLogo;

	@FindBy(name = "email")
	WebElement email;

	@FindBy(name = "password")
	WebElement password;

	@FindBy(xpath = "//*[contains(@class,\"ui fluid large blue submit button\")]")
	WebElement loginBtn;

	// Initializing the Objects
	public LoginPage() throws IOException {
		PageFactory.initElements(driver, this); // Driver is coming from base class and "this" means its pointing to
												// current class objects

	}

	// Actions :
	public String validateLoginPageTitle() {
		return driver.getTitle();

	}

	public boolean validateAndroidImage() {
		driver.manage().timeouts().pageLoadTimeout(TestUtil.page_load_timeout, TimeUnit.SECONDS);
		return androidLogo.isDisplayed();
	}

	public HomePage login(String mail, String pwd) throws IOException {
		login.click();
		email.sendKeys(mail);
		password.sendKeys(pwd);
		loginBtn.click();
		return new HomePage();
	}

}
