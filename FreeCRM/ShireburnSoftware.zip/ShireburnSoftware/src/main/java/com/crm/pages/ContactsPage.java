package com.crm.pages;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.crm.base.TestBase;

public class ContactsPage extends TestBase{
	
	@FindBy(xpath = "//div[contains(@class,'ui header item mb5 light-black')]")
	WebElement contactsLabel;
	
	@FindBy(xpath = "//button[contains(text(),\"New\")]")
	WebElement newButton;
	
	@FindBy(xpath = "//input[contains(@name,\"first_name\")]")
	WebElement firstName;
	
	@FindBy(xpath = "//input[contains(@name,\"last_name\")]")
	WebElement lastName;
	
	@FindBy(xpath = "//input[contains(@name,\"address\")]")
	WebElement address;
	
	@FindBy (xpath="//button[contains(text(),\"Save\")]")
	WebElement saveBtn;
	
	
	
	//Initialize the Page Objects

	public ContactsPage() throws IOException {
		PageFactory.initElements(driver,this);
		
	}
	
	public boolean verifyContactsLabel() {
		return contactsLabel.isDisplayed();
		
	}
	
	public void clickOnNewButton(String ftName,String ltName,String add) throws InterruptedException {
		newButton.click();
		firstName.sendKeys(ftName);
		lastName.sendKeys(ltName);
		address.sendKeys(add);
		saveBtn.click();
		Thread.sleep(2000);
	}

}
